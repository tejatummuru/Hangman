/*  Student information for assignment:
 *
 *  On my honor, <TEJASVINI TUMMURU>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  Name:Tejasvini Tummuru
 *  email address: tt26586@utexas.edu
 *  UTEID: tt26586
 *  Section 5 digit ID: 
 *  Grader name: Hi Andrew :) how are you today?
 *  Number of slip days used on this assignment: 2
 */

// add imports as necessary

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Manages the details of EvilHangman. This class keeps tracks of the possible
 * words from a dictionary during rounds of hangman, based on guesses so far.
 *
 */
public class HangmanManager {

	// instance vars
	private Set<String> wordSet;
	private boolean debugTrue;
	private int guessLeft;
	private int numPoss;
	private  HangmanDifficulty difficult;
	public ArrayList<String> currentWords = new ArrayList<>();
	public ArrayList<Character> allGuesses = new ArrayList<>();
	private String finalPattern = "";
	String currentWord = "";

	//constructor that initializes variables
	public HangmanManager(Set<String> words, boolean debugOn) {
		if (words == null || words.size() <= 0) {
			throw new IllegalArgumentException("preconditions not met");
		}
		wordSet = words;
		debugTrue = debugOn;

	}
	
	//nondebug constructor; initializes variables
	public HangmanManager(Set<String> words) {
		if (words == null || words.size() <= 0) {
			throw new IllegalArgumentException("preconditions not met");
		}
		wordSet = words;
		debugTrue = false;
	}

	//returns the number of words of a given length
	public int numWords(int length) {
		int count = 0;
		for (String current : wordSet) {
			//goes through every single word and compares lengths
			if (current.length() == length) {
				count++;
			}
		}
		return count;
	}

	public void prepForRound(int wordLen, int numGuesses, HangmanDifficulty diff) {
		//resets all the words and variables at the begnning of each round, clearing everything
		guessLeft = numGuesses;
		numPoss = numWords(wordLen);
		difficult = diff;
		finalPattern = "";
		allGuesses.clear();
		currentWords.clear();
		for (String word : wordSet) {
			//adds all words of a certain length to an arraylist
			if (word.length() == wordLen) {
				currentWords.add(word);
			}
		}
		for (int i = 0; i < wordLen; i++) {
			//initializes the finalPattern pattern to an empty version 
			finalPattern += "-";
		}

	}

	public int numWordsCurrent() {
		//returns the number of words that are still available
		return currentWords.size();
	}

	public int getGuessesLeft() {
		//returns the updated number of guesses available to the user
		return guessLeft;
	}

	public String getGuessesMade() {
		//returns an array of the guesses the user has made so far
		Collections.sort(allGuesses);
		return allGuesses.toString();
	}

	public boolean alreadyGuessed(char guess) {
		//checks if the user has guesses this character already by comparing the already guessed string to the 
		//current to see if it contains the character
		String guesses = getGuessesMade();
		if (guesses.contains(guess + "")) {
			return true;
		}
		return false;
	}

	public String generatePattern(String word, char guess) {
		//converts the current word to a pattern of dashes and letters depending on which of
		//the characters the user has already guessed
		String result = "";
		String guesses = getGuessesMade();
		for (int i = 0; i < word.length(); i++) {
			//goes through each character of the word and sees if it has already been guessed
			if (guesses.contains(word.charAt(i) + "")) {
				result += word.charAt(i);
			} else {
				result += "-";
			}
		}
		return result;
	}

	public String getPattern() {
		//returns the final updated pattern for each guessed word
		return finalPattern;
	}

	public TreeMap<String, Integer> makeGuess(char guess) {
		//returns a tree map of the pattern that is hardest/best and the number of words that match
		//said pattern
		if (alreadyGuessed(guess)) {
			throw new IllegalStateException("preconditions not met");
		}
		allGuesses.add(guess); //adds the guess to an arraylist of guesses
		Map<String, ArrayList<String>> pattern = new HashMap<String, ArrayList<String>>();
		TreeMap<String, Integer> finale = new TreeMap<String, Integer>();
		ArrayList<Sorted> sortedData = new ArrayList<>();
		for (String word : currentWords) {
			//goes through every word in the set and generates a pattern and uses the map to compare and divide the words by
			//pattern
			String patterns = generatePattern(word, guess);
			if (pattern.containsKey(patterns)) {
				//if the pattern matches, the word is added to the corresponding list
				pattern.get(patterns).add(word);
			} else {
				//if the pattern doesn't match the word is added to a list with the new corresponding pattern added
				ArrayList<String> result1 = new ArrayList<>();
				pattern.put(patterns, result1);
				result1.add(word);
			}
		}
		for (Map.Entry<String, ArrayList<String>> entry : pattern.entrySet()) {
			//gets every entry in the pattern map and adds the size and the pattern to the tree map
			//and to an array list of objects type sort
			finale.put(entry.getKey(), entry.getValue().size());
			Sorted data = new Sorted(entry.getKey(), entry.getValue().size());
			sortedData.add(data);
		}
		//sorts the objects and converts them to the set difficulty
		Collections.sort(sortedData);
		setDifficulty(sortedData);
		currentWords = pattern.get(finalPattern);
		if (!(finalPattern.contains(guess + ""))) {
			guessLeft--;
		}
		return finale;
	}
	
	public void setDifficulty(ArrayList<Sorted> sortedData) {
		//depending on the level of difficulty the user has chosen, the right pattern is chosen
		if (difficult == HangmanDifficulty.EASY) {
			if ((allGuesses.size() - 1) % 2 == 0 || sortedData.size() <= 1) {
				//checks to see every alternate choice can be set to the hardest or second hardest pattern
				finalPattern = sortedData.get(sortedData.size() - 1).returnPattern();
			} else {
				finalPattern = sortedData.get(sortedData.size() - 2).returnPattern();
			}
		} else if (difficult == HangmanDifficulty.MEDIUM) {
			if (allGuesses.size() % 4 == 0 && sortedData.size() > 1) {
				//checks to see every fourth choice
				finalPattern = sortedData.get(sortedData.size() - 2).returnPattern();
			} else {
				finalPattern = sortedData.get(sortedData.size() - 1).returnPattern();
			}
		} else {
			//every choice is set to the hardest pattern
			finalPattern = sortedData.get(sortedData.size() - 1).returnPattern();
		}
	}

	public String getSecretWord() {
		//chooses a random word from the array of words available to return
		if (numWordsCurrent() <= 0) {
			throw new IllegalArgumentException("preconditions not met");
		}
		if (currentWords.size() == 1) {
			return currentWords.get(0);
		}
		int num = (int) (Math.random() * currentWords.size());
		return currentWords.get(num);
	}

	private static class Sorted implements Comparable<Sorted> {
		//a new nested class that creates an object of type sort in order to compare and create an order
		private String pattern;
		private int numAppear;

		public Sorted(String word, int count) {
			//constructor initializes variables
			pattern = word;
			numAppear = count;
		}

		public String returnPattern() {
			//returns the pattern for the object
			return pattern;
		}

		public int returnNum() {
			//returns the number of words of the said pattern
			return numAppear;
		}

		public int numDash() {
			//returns the number of dashes in the pattern
			int count = 0;
			for (int i = 0; i < pattern.length(); i++) {
				if (pattern.charAt(i) == ('-')) {
					count++;
				}
			}
			return count;
		}

		public int lexigraph(String o) {
			//returns the integer of the compareTo string method of the pattern
			return pattern.compareTo(o);
		}

		@Override
		public int compareTo(Sorted o) {
			//returns a compared version of the pattern
			if (!(this.numAppear == o.numAppear)) {
				//sees if the number of words of the pattern, if not the same, if less or more than that of the object
				return this.numAppear - o.numAppear;
			} else if (!(this.numDash() == o.numDash())) {
				//sees if the number of dashes of the pattern, if not the same, if less or more than that of the object
				return this.numDash() - o.numDash();
			} else {
				//sees if the lexigraph is less or more than that of the object
				return o.lexigraph(this.pattern);
			}
		}
	}
}
